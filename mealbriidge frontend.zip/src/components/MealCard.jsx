function formatDate(d) {
  if (!d) return "Date not set";
  const date = new Date(`${d}T00:00:00`);
  if (isNaN(date)) return "Date not set";
  return date.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" });
}

function isUpcoming(meal) {
  if (!meal?.date || !meal?.time) return false;
  return new Date(`${meal.date}T${meal.time}:00`).getTime() >= Date.now();
}

function ratingSummary(meal) {
  if (!meal?.ratingCount) return "No ratings yet";
  return `${Number(meal.averageRating || 0).toFixed(1)} ★ from ${meal.ratingCount} rating${meal.ratingCount === 1 ? "" : "s"}`;
}

export default function MealCard({ meal, reserved, onReserve, onCancel, onRate, showActions = true }) {
  const upcoming = isUpcoming(meal);
  const reserved_ = Number(meal.reservedCount || 0);
  const capacity = Number(meal.capacity || 0);
  const full = capacity > 0 && reserved_ >= capacity;
  const spaces = capacity > 0 ? `${reserved_}/${capacity} reserved` : `${reserved_} reserved`;
  const canReserve = !reserved && meal.status === "active" && upcoming && !full;

  return (
    <article className="card meal-card">
      {meal.imageDataUrl && (
        <img className="meal-photo" src={meal.imageDataUrl} alt={`Photo of ${meal.title}`} />
      )}
      <div className="meal-info">
        <h3>{meal.title}</h3>
        {meal.description && <p>{meal.description}</p>}
        <p>
          <strong>{formatDate(meal.date)}</strong> at {meal.time}
        </p>
        <p>{meal.institutionName} — {meal.location}</p>
        <p className="meal-meta">{spaces} · {ratingSummary(meal)}</p>
        <span className={`pill ${meal.status === "inactive" ? "off" : ""}`}>
          {meal.status === "active" ? "Active" : "Inactive"}
        </span>
        {!upcoming && <span className="pill warn" style={{ marginLeft: 6 }}>Past</span>}
      </div>

      {showActions && (
        <div className="meal-actions" style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
          {reserved ? (
            <>
              <span className="pill">Reserved</span>
              {upcoming && (
                <button className="btn btn-secondary btn-small" onClick={() => onCancel?.(meal)}>
                  Cancel reservation
                </button>
              )}
              {!upcoming && (
                <button className="btn btn-secondary btn-small" onClick={() => onRate?.(meal)}>
                  Rate meal
                </button>
              )}
            </>
          ) : (
            <button
              className="btn btn-primary btn-small"
              disabled={!canReserve}
              onClick={() => onReserve?.(meal)}
            >
              {full ? "Fully booked" : !upcoming ? "Past" : "Reserve"}
            </button>
          )}
        </div>
      )}
    </article>
  );
}
