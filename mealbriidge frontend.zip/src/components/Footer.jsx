export default function Footer() {
  return <footer className="container footer">MealBridge demo website</footer>;
}
