import { Link, useLocation } from "react-router-dom";

export default function Navbar() {
  const { pathname } = useLocation();
  const link = (to, label) => (
    <Link className={pathname === to ? "active" : ""} to={to}>
      {label}
    </Link>
  );

  return (
    <header className="site-header">
      <div className="container navbar">
        <Link className="logo" to="/">
          <span className="logo-mark">MB</span> MealBridge
        </Link>
        <nav className="nav-links" aria-label="Main navigation">
          {link("/", "Home")}
          {link("/register", "Student register")}
          {link("/login", "Student login")}
          {link("/admin", "Admin")}
        </nav>
      </div>
    </header>
  );
}
