import LoginForm from "../components/LoginForm";

export default function Login() {
  return (
    <main className="container">
      <section className="page-title">
        <p className="eyebrow">Student access</p>
        <h1>Log in to reserve meals.</h1>
      </section>
      <LoginForm />
    </main>
  );
}
