import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { session } from "../services/api";
import { authService } from "../services/authService";
import { mealService } from "../services/mealService";
import { reservationService } from "../services/reservationService";
import { ratingService } from "../services/ratingService";
import MealList from "../components/MealList";
import RatingForm from "../components/RatingForm";

export default function StudentDashboard() {
  const navigate = useNavigate();
  const student = session.getStudent();

  const [meals, setMeals] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [ratingMeal, setRatingMeal] = useState(null);
  const [notice, setNotice] = useState(null);

  useEffect(() => {
    if (!student) { navigate("/login"); return; }
    loadData();
  }, []);

  async function loadData() {
    try {
      const [mealsRes, resRes] = await Promise.all([
        mealService.getStudentMeals(),
        reservationService.getStudentReservations(),
      ]);
      setMeals(mealsRes.meals || []);
      setReservations(resRes.reservations || []);
    } catch (err) {
      setNotice({ type: "error", message: err.message });
    }
  }

  async function handleReserve(meal) {
    try {
      await reservationService.reserveMeal(meal.id);
      await loadData();
      setNotice({ type: "success", message: `Reserved: ${meal.title}` });
    } catch (err) {
      setNotice({ type: "error", message: err.message });
    }
  }

  async function handleCancel(meal) {
    try {
      await reservationService.cancelReservation(meal.id);
      await loadData();
      setNotice({ type: "success", message: "Reservation cancelled." });
    } catch (err) {
      setNotice({ type: "error", message: err.message });
    }
  }

  async function handleRate(mealId, rating, comment) {
    await ratingService.rateMeal(mealId, rating, comment);
    await loadData();
    setRatingMeal(null);
  }

  function handleLogout() {
    authService.logoutStudent();
    navigate("/login");
  }

  if (!student) return null;

  const reservedMealIds = reservations.map((r) => r.mealId);
  const reservedMeals = meals.filter((m) => reservedMealIds.includes(m.id));
  const availableMeals = meals.filter((m) => !reservedMealIds.includes(m.id));

  return (
    <main className="container">
      <section className="page-title">
        <p className="eyebrow">Student dashboard</p>
        <h1>Welcome, {student.fullName}.</h1>
      </section>

      {notice && (
        <div className={`notice show ${notice.type}`} style={{ marginBottom: 16 }}>
          {notice.message}
        </div>
      )}

      <section className="dashboard-layout">
        <aside className="card sidebar">
          <h3>Your profile</h3>
          <p><strong>Status:</strong><br /><span className={`pill ${student.status === "approved" ? "" : "warn"}`}>{student.status}</span></p>
          <p><strong>Email:</strong><br />{student.email}</p>
          <p><strong>Student number:</strong><br />{student.studentNumber}</p>
          <p><strong>Institution:</strong><br />{student.institutionName}</p>
          <p><strong>Location:</strong><br />{student.location}</p>
          <button className="btn btn-secondary" onClick={handleLogout} style={{ marginTop: 12 }}>
            Log out
          </button>
        </aside>

        <div className="grid-2">
          <section className="card">
            <h2>Available meals</h2>
            <p>Reserve an active upcoming meal from the calendar below.</p>
            <MealList
              meals={availableMeals}
              reservedIds={[]}
              onReserve={handleReserve}
            />
          </section>

          <section className="card">
            <h2>Your reservations and ratings</h2>
            <p>Your reservations appear here. You can cancel upcoming reservations and rate past meals.</p>
            {ratingMeal && (
              <RatingForm
                meal={ratingMeal}
                onSubmit={handleRate}
                onClose={() => setRatingMeal(null)}
              />
            )}
            <MealList
              meals={reservedMeals}
              reservedIds={reservedMealIds}
              onCancel={handleCancel}
              onRate={(meal) => setRatingMeal(meal)}
            />
          </section>
        </div>
      </section>
    </main>
  );
}
