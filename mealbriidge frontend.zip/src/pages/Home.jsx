import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import MealList from "../components/MealList";
import { mealService } from "../services/mealService";

export default function Home() {
  const [meals, setMeals] = useState([]);

  useEffect(() => {
    mealService.getPublicMeals().then((d) => setMeals(d.meals || [])).catch(() => {});
  }, []);

  return (
    <main>
      <section className="container hero">
        <div>
          <p className="eyebrow">Campus food support platform</p>
          <h1>Connect students with available meals.</h1>
          <p className="lead">
            MealBridge lets students register for support, wait for admin approval, view meal
            availability, reserve meals, and rate meals. Admins can manage institutions, approve
            students, add meal photos, and update the meal calendar from one simple dashboard.
          </p>
          <div className="actions">
            <Link className="btn btn-primary" to="/register">Register as a student</Link>
            <Link className="btn btn-secondary" to="/admin">Admin dashboard</Link>
          </div>
        </div>

        <aside className="hero-card" aria-label="MealBridge overview">
          <div className="food-panel"></div>
          <div className="stats-grid">
            <div className="stat"><strong>01</strong><span>Register</span></div>
            <div className="stat"><strong>02</strong><span>View meals</span></div>
            <div className="stat"><strong>03</strong><span>Reserve</span></div>
          </div>
          <p className="lead" style={{ fontSize: "1rem", marginBottom: 0 }}>
            MealBridge connects students with available campus meals.
          </p>
        </aside>
      </section>

      <section className="container section">
        <p className="eyebrow">How it works</p>
        <h2>Simple tools for students and admins.</h2>
        <div className="grid-3">
          <article className="card">
            <h3>Student registration</h3>
            <p>New students submit their institution, CNIC, age, city, and contact details. Admins approve entries before students join the meal plan.</p>
          </article>
          <article className="card">
            <h3>Meal calendar</h3>
            <p>Students can see active meals with institution, date, time, location, capacity, rating, and meal photo.</p>
          </article>
          <article className="card">
            <h3>Admin management</h3>
            <p>The admin can add institutions, approve or remove students, upload meal pictures, and manage reservations.</p>
          </article>
        </div>
      </section>

      <section className="container section">
        <p className="eyebrow">Upcoming meals</p>
        <h2>Meal calendar preview</h2>
        <div style={{ marginTop: 24 }}>
          <MealList meals={meals} showActions={false} />
        </div>
      </section>
    </main>
  );
}
