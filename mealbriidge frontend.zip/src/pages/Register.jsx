import RegisterForm from "../components/RegisterForm";

export default function Register() {
  return (
    <main className="container">
      <section className="page-title">
        <p className="eyebrow">Student intake</p>
        <h1>Register for MealBridge.</h1>
        <p className="lead">
          Submit your details for admin approval. Approved students can log in, reserve meals, and rate meals.
        </p>
      </section>
      <RegisterForm />
    </main>
  );
}
